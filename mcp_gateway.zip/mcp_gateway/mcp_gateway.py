from contextlib import asynccontextmanager
import fastapi
from ray import serve
from mcp.server.fastmcp import FastMCP

# --------------------------------------------------------------------------
# 1.  Create FastMCP in stateless http (streamable) mode
# --------------------------------------------------------------------------
mcp = FastMCP("Example MCP Gateway", stateless_http=True)

# --------------------------------------------------------------------------
# 2.  Register your tools BEFORE mounting the app
# --------------------------------------------------------------------------

@mcp.tool()
async def mcp_calculator(arg1: int, arg2: int) -> str:
    calculator = serve.get_deployment_handle("mcp_calculator", app_name="mcp_calculator")
    return await calculator.calculate.remote(arg1, arg2)


@mcp.tool()
async def mcp_text_length(text: str) -> str:
    return "Text length: " + str(len(text))

# @mcp.tool()
# async def mcp_text_processor(text: str) -> str:
#     """Translate English → French."""
#     text_processor  = serve.get_deployment_handle("mcp_text_processor", app_name="mcp_text_processor")
#     return await text_processor.process.remote(text)


# ----------------------------------------------------------------------------
# 3.  Build FastAPI app with lifespan to mount the FastMCP streamable HTTP app
# ----------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: fastapi.FastAPI):
    # After startup, mount the streamable-http MCP app.
    app.mount("/", mcp.streamable_http_app())

    # Keep MCP’s session manager running for the lifetime of this process.
    async with mcp.session_manager.run():
        yield

api = fastapi.FastAPI(lifespan=lifespan)

# --------------------------------------------------------------------------
# 4.  Wrap in a Ray Serve deployment
# --------------------------------------------------------------------------
@serve.deployment(
    autoscaling_config={
        "min_replicas": 1,
        "max_replicas": 10,
        "target_ongoing_requests": 3,
    },
    ray_actor_options={
        "num_cpus": 0.1
    }
)
@serve.ingress(api)
class MCPGateway:

    def __init__(self):
        pass  


# --------------------------------------------------------------------------
# 5.  Expose the Serve app graph
# --------------------------------------------------------------------------
app = MCPGateway.bind()
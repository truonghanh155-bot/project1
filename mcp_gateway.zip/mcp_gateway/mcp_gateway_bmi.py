from contextlib import asynccontextmanager
import fastapi
from ray import serve
from mcp.server.fastmcp import FastMCP

# --------------------------------------------------------------------------
# 1.  Create FastMCP in stateless http (streamable) mode
# --------------------------------------------------------------------------
mcp = FastMCP("BMI MCP Gateway", stateless_http=True)

# --------------------------------------------------------------------------
# 2.  Register your tools BEFORE mounting the app
# --------------------------------------------------------------------------

@mcp.tool()
async def calculate_bmi(weight_kg: float, height_m: float) -> dict:
    """
    Calculate BMI given weight in kg and height in meters.
    
    Args:
        weight_kg: Weight in kilograms (1-1000)
        height_m: Height in meters (0.3-3.0)
        
    Returns:
        Dictionary with BMI value, category, and input values
    """
    # Input validation
    if not (1.0 <= weight_kg <= 1000.0):
        raise ValueError("Weight must be between 1 and 1000 kg")
    
    if not (0.3 <= height_m <= 3.0):
        raise ValueError("Height must be between 0.3 and 3.0 meters")
    
    if height_m <= 0:
        raise ValueError("Height must be > 0")
    
    # Calculate BMI
    bmi_value = weight_kg / (height_m ** 2)
    
    # Get BMI category based on WHO standards
    if bmi_value < 18.5:
        category = "Underweight"
    elif bmi_value < 25.0:
        category = "Normal weight"
    elif bmi_value < 30.0:
        category = "Overweight"
    else:
        category = "Obese"
    
    return {
        "bmi": round(bmi_value, 2),
        "category": category,
        "weight_kg": weight_kg,
        "height_m": height_m
    }

@mcp.tool()
async def get_bmi_category(bmi: float) -> str:
    """
    Get BMI category based on WHO standards.
    
    Args:
        bmi: BMI value
        
    Returns:
        BMI category string
    """
    if not (0.1 <= bmi <= 100.0):
        raise ValueError("BMI must be between 0.1 and 100.0")
    
    if bmi < 18.5:
        return "Underweight"
    elif bmi < 25.0:
        return "Normal weight"
    elif bmi < 30.0:
        return "Overweight"
    else:
        return "Obese"

# ----------------------------------------------------------------------------
# 3.  Build FastAPI app with lifespan to mount the FastMCP streamable HTTP app
# ----------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: fastapi.FastAPI):
    # After startup, mount the streamable-http MCP app.
    app.mount("/", mcp.streamable_http_app())

    # Keep MCP's session manager running for the lifetime of this process.
    async with mcp.session_manager.run():
        yield

api = fastapi.FastAPI(lifespan=lifespan)

# --------------------------------------------------------------------------
# 4.  Wrap in a Ray Serve deployment
# --------------------------------------------------------------------------
@serve.deployment(
    autoscaling_config={
        "min_replicas": 1,
        "max_replicas": 5,
        "target_ongoing_requests": 10,
    },
    ray_actor_options={
        "num_cpus": 0.2
    }
)
@serve.ingress(api)
class BMIDeployment:

    def __init__(self):
        pass  


# --------------------------------------------------------------------------
# 5.  Expose the Serve app graph
# --------------------------------------------------------------------------
bmi_gateway = BMIDeployment.bind()
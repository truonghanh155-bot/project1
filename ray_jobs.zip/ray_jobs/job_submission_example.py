"""
Example demonstrating how to submit Ray jobs programmatically.

This script shows how to use the RayJobSubmitter class to submit jobs to a Ray cluster.
"""

import sys
import os

# Add parent directory to path to import ray_job_submitter
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ray_job_submitter import RayJobSubmitter, JobConfig, SubmissionMethod, submit_python_script

def main():
    print("Ray Job Submission Example")
    print("=" * 50)
    
    # Example 1: Submit the simple hello world script
    print("\n1. Submitting simple hello world script...")
    try:
        result = submit_python_script(
            script_path="ray_job_example.py",
            cluster_address="http://127.0.0.1:8265",
            working_dir="./ray_jobs",
            wait_for_completion=True
        )
        print(f"Job result: {result}")
    except Exception as e:
        print(f"Job submission failed: {e}")
    
    # Example 2: Submit with custom configuration using the submitter class
    print("\n2. Submitting job with custom configuration...")
    submitter = RayJobSubmitter("http://127.0.0.1:8265")
    
    config = JobConfig(
        entrypoint="python ray_job_example.py",
        working_dir="./ray_jobs",
        runtime_env={
            "pip": [],  # No additional packages needed for this simple example
            "env_vars": {"PYTHONPATH": "/tmp"}
        },
        metadata={"experiment": "hello_world_test", "version": "1.0"}
    )
    
    try:
        result = submitter.submit_job(
            config, 
            method=SubmissionMethod.SDK,
            wait_for_completion=True,
            log_tail=True
        )
        print(f"Custom job completed: {result}")
        
    except Exception as e:
        print(f"Custom job failed: {e}")
    
    # Example 3: List all jobs
    print("\n3. Listing all jobs...")
    try:
        jobs = submitter.list_jobs()
        print(f"Found {len(jobs)} jobs:")
        for job in jobs:
            print(f"  - Job ID: {job.get('job_id', 'N/A')}, Status: {job.get('status', 'N/A')}")
    except Exception as e:
        print(f"Failed to list jobs: {e}")
    
    print("\nExample completed!")

if __name__ == "__main__":
    main()
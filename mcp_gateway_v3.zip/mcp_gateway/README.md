run the mcp inspector 
npx -y @modelcontextprotocol/inspector@0.16.1
podman machine start
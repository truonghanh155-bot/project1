from contextlib import asynccontextmanager
import os
import pathlib
from pathlib import Path
from typing import Optional
import fastapi
from ray import serve
from mcp.server.fastmcp import FastMCP, Context

# --------------------------------------------------------------------------
# 1.  Create FastMCP in stateless http (streamable) mode
# --------------------------------------------------------------------------
mcp = FastMCP("MCP Gateway for Read Write with Session ID", stateless_http=True)

# --------------------------------------------------------------------------
# 2.  Session-based file operations with security
# --------------------------------------------------------------------------

def get_session_directory(session_id: str) -> Path:
    """Get the session-specific directory, creating it if needed."""
    session_dir = Path("/tmp/mcp_sessions") / session_id
    session_dir.mkdir(parents=True, exist_ok=True)
    return session_dir

def validate_file_path(file_path: str, session_dir: Path) -> Path:
    """Validate and resolve file path within session directory."""
    try:
        # Convert to Path and resolve
        path = Path(file_path)
        
        # If path is absolute, make it relative to session directory
        if path.is_absolute():
            path = path.relative_to(path.anchor)
        
        # Construct the full path within session directory
        full_path = session_dir / path
        
        # Resolve both paths for comparison (handle symlinks like /tmp -> /private/tmp)
        resolved_full_path = full_path.resolve()
        resolved_session_dir = session_dir.resolve()
        
        # Ensure the resolved path is within the session directory
        try:
            resolved_full_path.relative_to(resolved_session_dir)
        except ValueError:
            raise ValueError("Path traversal attempt detected")
        
        return full_path
    except Exception as e:
        if "Path traversal attempt detected" in str(e):
            raise e
        raise ValueError(f"Invalid file path: {e}")

# --------------------------------------------------------------------------
# 3.  Register MCP tools
# --------------------------------------------------------------------------

@mcp.tool()
async def mcp_read_file(file_path: str, session_id: str, ctx: Context) -> str:
    """Read file content from session-specific directory.
    
    Args:
        file_path: Path to the file to read (relative to session directory)
        session_id: Session identifier for file isolation
        ctx: FastMCP context for session management
    
    Returns:
        File content as string or error message
    """
    try:
        # Use provided session_id or fall back to context session_id
        active_session_id = session_id or ctx.session_id()
        if not active_session_id:
            return "Error: No session ID provided"
        
        # Get session directory and validate file path
        session_dir = get_session_directory(active_session_id)
        validated_path = validate_file_path(file_path, session_dir)
        
        # Check if file exists
        if not validated_path.exists():
            return f"Error: File '{file_path}' not found in session {active_session_id}"
        
        if not validated_path.is_file():
            return f"Error: '{file_path}' is not a file"
        
        # Read and return file content
        with open(validated_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return f"File content ({len(content)} characters):\n{content}"
        
    except ValueError as e:
        return f"Error: {e}"
    except PermissionError:
        return f"Error: Permission denied reading '{file_path}'"
    except UnicodeDecodeError:
        return f"Error: Cannot read '{file_path}' - file appears to be binary"
    except Exception as e:
        return f"Error: Unexpected error reading '{file_path}': {e}"

@mcp.tool()
async def mcp_write_file(file_path: str, content: str, session_id: str, ctx: Context) -> str:
    """Write content to a file in session-specific directory.
    
    Args:
        file_path: Path to the file to write (relative to session directory)
        content: Content to write to the file
        session_id: Session identifier for file isolation
        ctx: FastMCP context for session management
    
    Returns:
        Success message or error message
    """
    try:
        # Use provided session_id or fall back to context session_id
        active_session_id = session_id or ctx.session_id()
        if not active_session_id:
            return "Error: No session ID provided"
        
        # Get session directory and validate file path
        session_dir = get_session_directory(active_session_id)
        validated_path = validate_file_path(file_path, session_dir)
        
        # Create parent directories if they don't exist
        validated_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Write content to file
        with open(validated_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        file_size = validated_path.stat().st_size
        return f"Success: Written {len(content)} characters ({file_size} bytes) to '{file_path}' in session {active_session_id}"
        
    except ValueError as e:
        return f"Error: {e}"
    except PermissionError:
        return f"Error: Permission denied writing to '{file_path}'"
    except OSError as e:
        return f"Error: Cannot write to '{file_path}': {e}"
    except Exception as e:
        return f"Error: Unexpected error writing '{file_path}': {e}"

@mcp.tool()
async def mcp_list_files(directory: str, session_id: str, ctx: Context) -> str:
    """List files and directories in session-specific directory.
    
    Args:
        directory: Directory path to list (relative to session directory, use "." for root)
        session_id: Session identifier for file isolation
        ctx: FastMCP context for session management
    
    Returns:
        List of files and directories or error message
    """
    try:
        # Use provided session_id or fall back to context session_id
        active_session_id = session_id or ctx.session_id()
        if not active_session_id:
            return "Error: No session ID provided"
        
        # Get session directory and validate directory path
        session_dir = get_session_directory(active_session_id)
        validated_path = validate_file_path(directory, session_dir)
        
        # Check if directory exists
        if not validated_path.exists():
            return f"Error: Directory '{directory}' not found in session {active_session_id}"
        
        if not validated_path.is_dir():
            return f"Error: '{directory}' is not a directory"
        
        # List contents
        items = []
        for item in sorted(validated_path.iterdir()):
            item_type = "DIR" if item.is_dir() else "FILE"
            item_size = item.stat().st_size if item.is_file() else "-"
            relative_path = item.relative_to(session_dir)
            items.append(f"{item_type:4} {item_size:>8} {relative_path}")
        
        if not items:
            return f"Directory '{directory}' is empty"
        
        return f"Contents of '{directory}' in session {active_session_id}:\n" + "\n".join(items)
        
    except ValueError as e:
        return f"Error: {e}"
    except PermissionError:
        return f"Error: Permission denied accessing '{directory}'"
    except Exception as e:
        return f"Error: Unexpected error listing '{directory}': {e}"

@mcp.tool()
async def mcp_delete_file(file_path: str, session_id: str, ctx: Context) -> str:
    """Delete a file from session-specific directory.
    
    Args:
        file_path: Path to the file to delete (relative to session directory)
        session_id: Session identifier for file isolation
        ctx: FastMCP context for session management
    
    Returns:
        Success message or error message
    """
    try:
        # Use provided session_id or fall back to context session_id
        active_session_id = session_id or ctx.session_id()
        if not active_session_id:
            return "Error: No session ID provided"
        
        # Get session directory and validate file path
        session_dir = get_session_directory(active_session_id)
        validated_path = validate_file_path(file_path, session_dir)
        
        # Check if file exists
        if not validated_path.exists():
            return f"Error: File '{file_path}' not found in session {active_session_id}"
        
        if not validated_path.is_file():
            return f"Error: '{file_path}' is not a file"
        
        # Delete the file
        validated_path.unlink()
        
        return f"Success: Deleted '{file_path}' from session {active_session_id}"
        
    except ValueError as e:
        return f"Error: {e}"
    except PermissionError:
        return f"Error: Permission denied deleting '{file_path}'"
    except Exception as e:
        return f"Error: Unexpected error deleting '{file_path}': {e}"

@mcp.tool()
async def mcp_file_info(file_path: str, session_id: str, ctx: Context) -> str:
    """Get information about a file in session-specific directory.
    
    Args:
        file_path: Path to the file to inspect (relative to session directory)
        session_id: Session identifier for file isolation
        ctx: FastMCP context for session management
    
    Returns:
        File information or error message
    """
    try:
        # Use provided session_id or fall back to context session_id
        active_session_id = session_id or ctx.session_id()
        if not active_session_id:
            return "Error: No session ID provided"
        
        # Get session directory and validate file path
        session_dir = get_session_directory(active_session_id)
        validated_path = validate_file_path(file_path, session_dir)
        
        # Check if file exists
        if not validated_path.exists():
            return f"Error: File '{file_path}' not found in session {active_session_id}"
        
        # Get file information
        stat = validated_path.stat()
        file_type = "Directory" if validated_path.is_dir() else "File"
        
        import datetime
        modified_time = datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
        
        info = [
            f"File Info for '{file_path}' in session {active_session_id}:",
            f"Type: {file_type}",
            f"Size: {stat.st_size} bytes",
            f"Modified: {modified_time}",
            f"Permissions: {oct(stat.st_mode)[-3:]}",
        ]
        
        return "\n".join(info)
        
    except ValueError as e:
        return f"Error: {e}"
    except PermissionError:
        return f"Error: Permission denied accessing '{file_path}'"
    except Exception as e:
        return f"Error: Unexpected error getting info for '{file_path}': {e}"


# ----------------------------------------------------------------------------
# 4.  Build FastAPI app with lifespan to mount the FastMCP streamable HTTP app
# ----------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: fastapi.FastAPI):
    # After startup, mount the streamable-http MCP app.
    app.mount("/", mcp.streamable_http_app())

    # Keep MCP's session manager running for the lifetime of this process.
    async with mcp.session_manager.run():
        yield

api = fastapi.FastAPI(lifespan=lifespan)

# --------------------------------------------------------------------------
# 5.  Wrap in a Ray Serve deployment
# --------------------------------------------------------------------------
@serve.deployment(
    autoscaling_config={
        "min_replicas": 1,
        "max_replicas": 5,
        "target_ongoing_requests": 10,
    },
    ray_actor_options={
        "num_cpus": 0.2,
        "memory": 512 * 1024 * 1024  # 512MB
    }
)
@serve.ingress(api)
class MCPReadWriteGateway:

    def __init__(self):
        pass  


# --------------------------------------------------------------------------
# 6.  Expose the Serve app graph
# --------------------------------------------------------------------------
app = MCPReadWriteGateway.bind()

#!/bin/bash
# Solution 1: Deploy using Storage Class with Mount Options

echo "Deploying Solution 1: Storage Class with Mount Options"

# Apply storage class
echo "Creating storage class with mount options..."
kubectl apply -f storage-class.yaml

# Apply PVC
echo "Creating PVC..."
kubectl apply -f pvc.yaml

# Wait for PVC to be bound
echo "Waiting for PVC to be bound..."
kubectl wait --for=condition=Bound pvc/pvc-blob-files-agentic-storage-v2 --timeout=60s

# Apply Ray Service
echo "Creating Ray Service..."
kubectl apply -f ray-service.yaml

echo "Solution 1 deployed successfully!"
echo "Check status with:"
echo "  kubectl get pvc pvc-blob-files-agentic-storage-v2"
echo "  kubectl get rayservice rayservice-samplev3-solution1"
echo ""
echo "Test access with:"
echo "  kubectl exec -it \$(kubectl get pods -l ray.io/cluster=rayservice-samplev3-solution1 -l ray.io/node-type=worker -o jsonpath='{.items[0].metadata.name}') -- ls -la /mnt/shared"
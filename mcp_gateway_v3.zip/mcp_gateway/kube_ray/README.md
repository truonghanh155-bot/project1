# Solution 1: Storage Class with Mount Options

This solution creates a new StorageClass with Azure CSI mount options that set proper permissions for the Ray containers.

## Files
- `storage-class.yaml` - StorageClass with mount options
- `pvc.yaml` - PersistentVolumeClaim using the new StorageClass
- `ray-service.yaml` - Ray Service configuration
- `deploy.sh` - Deployment script

## Mount Options Explained
- `dir_mode=0755` - Directory permissions (rwxr-xr-x)
- `file_mode=0644` - File permissions (rw-r--r--)
- `uid=1000` - Set owner to ray user (UID 1000)
- `gid=100` - Set group to users (GID 100)
- `allow_other` - Allow other users to access the mount

## Deployment

```bash
chmod +x deploy.sh
./deploy.sh
```

## Testing

After deployment, test access:

```bash
# Get worker pod name
WORKER_POD=$(kubectl get pods -l ray.io/cluster=rayservice-samplev3-solution1 -l ray.io/node-type=worker -o jsonpath='{.items[0].metadata.name}')

# Test directory access
kubectl exec -it $WORKER_POD -- ls -la /mnt/shared

# Test file creation
kubectl exec -it $WORKER_POD -- touch /mnt/shared/test-file.txt
kubectl exec -it $WORKER_POD -- ls -la /mnt/shared/test-file.txt
```

## Pros
- Clean solution using Kubernetes StorageClass
- Automatically applies to all PVCs using this StorageClass
- Easy to manage and reuse

## Cons
- Requires creating a new StorageClass
- All volumes using this StorageClass will have the same mount options
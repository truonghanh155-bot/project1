import math
import operator
import re
from typing import Union, Dict, Any
import starlette
from ray import serve


@serve.deployment(
    name="mcp_calculator",
    autoscaling_config={
        "min_replicas": 1,
        "max_replicas": 5,
        "target_num_ongoing_requests_per_replica": 10,
    },
    ray_actor_options={
        "num_cpus": 0.1
    }
)
class Calculator:
    def __init__(self):
        self.operations = {
            '+': operator.add,
            '-': operator.sub,
            '*': operator.mul,
            '/': operator.truediv,
            '%': operator.mod,
            '**': operator.pow,
            '^': operator.pow,
        }
        
        self.functions = {
            'sqrt': math.sqrt,
            'abs': abs,
            'sin': math.sin,
            'cos': math.cos,
            'tan': math.tan,
            'log': math.log,
            'ln': math.log,
            'exp': math.exp,
        }

    def _parse_expression(self, expression: str) -> float:
        """Parse and evaluate a mathematical expression safely."""
        try:
            expression = expression.strip()
            
            # Handle function calls
            for func_name, func in self.functions.items():
                pattern = f'{func_name}\\(([^)]+)\\)'
                while re.search(pattern, expression):
                    match = re.search(pattern, expression)
                    if match:
                        arg = float(match.group(1))
                        result = func(arg)
                        expression = expression.replace(match.group(0), str(result))
            
            # Replace ^ with ** for power operations
            expression = expression.replace('^', '**')
            
            # Evaluate the expression safely
            allowed_chars = set('0123456789+-*/.() ')
            if all(c in allowed_chars or c.isspace() for c in expression):
                result = eval(expression, {"__builtins__": {}}, {})
                return float(result)
            else:
                raise ValueError("Invalid characters in expression")
                
        except Exception as e:
            raise ValueError(f"Invalid expression: {str(e)}")

    def _basic_operation(self, arg1: Union[int, float], arg2: Union[int, float], operation: str = '+') -> float:
        """Perform basic arithmetic operations."""
        try:
            arg1, arg2 = float(arg1), float(arg2)
            
            if operation not in self.operations:
                raise ValueError(f"Unsupported operation: {operation}")
            
            if operation == '/' and arg2 == 0:
                raise ValueError("Division by zero is not allowed")
            
            if operation == '%' and arg2 == 0:
                raise ValueError("Modulo by zero is not allowed")
            
            result = self.operations[operation](arg1, arg2)
            return result
            
        except ValueError as e:
            raise e
        except Exception as e:
            raise ValueError(f"Calculation error: {str(e)}")

    async def calculate(self, arg1: Union[int, float, str], arg2: Union[int, float, str] = None) -> str:
        """
        Main calculation method that handles both basic operations and expressions.
        
        Args:
            arg1: First number or mathematical expression
            arg2: Second number (optional, used for basic operations)
        
        Returns:
            String representation of the calculation result
        """
        try:
            # If arg2 is None or arg1 is a string with operators, treat as expression
            if arg2 is None or (isinstance(arg1, str) and any(op in str(arg1) for op in ['+', '-', '*', '/', '(', ')'])):
                if isinstance(arg1, str):
                    result = self._parse_expression(arg1)
                    return f"Result: {result}"
                else:
                    return f"Result: {float(arg1)}"
            
            # Basic two-operand operations (default to addition)
            result = self._basic_operation(arg1, arg2, '+')
            return f"Result: {result}"
            
        except ValueError as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Error: Unexpected calculation error - {str(e)}"

    async def __call__(self, req: starlette.requests.Request) -> Dict[str, Any]:
        """HTTP endpoint for calculator service."""
        try:
            req_data = await req.json()
            arg1 = req_data.get("arg1")
            arg2 = req_data.get("arg2")
            
            if arg1 is None:
                return {"error": "arg1 is required"}
            
            result = await self.calculate(arg1, arg2)
            return {"result": result}
            
        except Exception as e:
            return {"error": f"Request processing error: {str(e)}"}


app = Calculator.bind()
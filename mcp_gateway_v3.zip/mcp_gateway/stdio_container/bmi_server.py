#!/usr/bin/env python3

from mcp.server.fastmcp import FastMCP

# Create an MCP server named “BMI Server”
mcp = FastMCP("BMI Server")

@mcp.tool()
def calculate_bmi(weight_kg: float, height_m: float) -> float:
    """
    Calculate BMI given weight in kg and height in meters.
    """
    if height_m <= 0:
        raise ValueError("Height must be > 0")
    return weight_kg / (height_m ** 2)

if __name__ == "__main__":
    # Run using stdio transport
    mcp.run(transport="stdio")

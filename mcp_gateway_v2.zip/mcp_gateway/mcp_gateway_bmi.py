#!/usr/bin/env python3
"""
BMI MCP Gateway - Ray Serve deployment for BMI calculation MCP service.

This module provides a Ray Serve deployment that runs BMI calculation
tools in a containerized MCP server via stdio communication.
"""

import asyncio
import logging
import os
from contextlib import AsyncExitStack
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Request
from ray import serve

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("BMIGateway")

# FastAPI app for HTTP endpoints
app = FastAPI(
    title="BMI MCP Gateway",
    description="Ray Serve deployment for BMI calculation MCP service",
    version="1.0.0"
)


@serve.deployment(
    num_replicas=2,
    autoscaling_config={
        "min_replicas": 1,
        "max_replicas": 5,
        "target_num_ongoing_requests_per_replica": 10,
    },
    ray_actor_options={"num_cpus": 0.1},
    health_check_period_s=10,
    health_check_timeout_s=30,
)
@serve.ingress(app)
class BMIDeployment:
    """
    Ray Serve deployment for BMI calculation MCP service.
    
    This deployment manages containerized BMI calculation tools via stdio MCP protocol.
    It provides HTTP endpoints for tool discovery and execution.
    """

    def __init__(self) -> None:
        """Initialize the BMI deployment."""
        self._ready = asyncio.create_task(self._initialize())
        self._exit_stack: Optional[AsyncExitStack] = None
        self.session: Optional[ClientSession] = None

    async def _initialize(self) -> None:
        """Initialize the MCP session with the BMI container."""
        try:
            # Build the container image if it doesn't exist
            # await self._ensure_container_built()
            
            # Setup stdio server parameters for BMI container
            params = StdioServerParameters(
                command="podman",  # or "podman" if preferred
                args=[
                    "run",
                    "-i",
                    "--rm",
                    "--name", f"bmi-server-{id(self)}",
                    "docker.io/tanle2694docker/bmi-mcp:latest",
                ],
                env=os.environ.copy(),
            )

            self._exit_stack = AsyncExitStack()

            # Start stdio client communication with container
            stdin, stdout = await self._exit_stack.enter_async_context(
                stdio_client(params)
            )

            # Initialize MCP session
            self.session = await self._exit_stack.enter_async_context(
                ClientSession(stdin, stdout)
            )
            await self.session.initialize()

            logger.info("BMI MCP Gateway replica ready and initialized")

        except Exception as e:
            logger.error(f"Failed to initialize BMI deployment: {e}")
            raise

    # async def _ensure_container_built(self) -> None:
    #     """Ensure the BMI container image is built."""
    #     import subprocess
        
    #     try:
    #         # Check if image exists
    #         result = subprocess.run(
    #             ["docker", "images", "-q", "bmi-mcp-server"],
    #             capture_output=True,
    #             text=True,
    #             check=False
    #         )
            
    #         if not result.stdout.strip():
    #             logger.info("Building BMI container image...")
    #             # Build the container from stdio_container directory
    #             build_result = subprocess.run(
    #                 [
    #                     "docker", "build", 
    #                     "-t", "bmi-mcp-server",
    #                     "./stdio_container"
    #                 ],
    #                 cwd="/Users/admin/workspace/yoko/pocs/ray_mcp/mcp_gateway",
    #                 capture_output=True,
    #                 text=True,
    #                 check=True
    #             )
    #             logger.info("BMI container image built successfully")
    #         else:
    #             logger.info("BMI container image already exists")
                
    #     except subprocess.CalledProcessError as e:
    #         logger.error(f"Failed to build BMI container: {e.stderr}")
    #         raise RuntimeError(f"Container build failed: {e.stderr}")

    async def _ensure_ready(self) -> None:
        """Ensure the deployment is fully initialized."""
        await self._ready

    async def _list_tools(self) -> List[Dict[str, Any]]:
        """List all available tools from the BMI MCP server."""
        await self._ensure_ready()
        
        if not self.session:
            raise RuntimeError("MCP session not initialized")
            
        try:
            resp = await self.session.list_tools()
            return [
                {
                    "name": tool.name,
                    "description": tool.description,
                    "input_schema": tool.inputSchema,
                }
                for tool in resp.tools
            ]
        except Exception as e:
            logger.error(f"Failed to list tools: {e}")
            raise

    async def _call_tool(self, tool_name: str, tool_args: Dict[str, Any]) -> Any:
        """Call a specific tool with the provided arguments."""
        await self._ensure_ready()
        
        if not self.session:
            raise RuntimeError("MCP session not initialized")
            
        try:
            result = await self.session.call_tool(tool_name, tool_args)
            return result
        except Exception as e:
            logger.error(f"Failed to call tool {tool_name}: {e}")
            raise

    def _get_bmi_category(self, bmi: float) -> str:
        """Get BMI category based on WHO standards."""
        if bmi < 18.5:
            return "Underweight"
        elif bmi < 25.0:
            return "Normal weight"
        elif bmi < 30.0:
            return "Overweight"
        else:
            return "Obese"

    # HTTP Endpoints

    @app.get("/health")
    async def health_check(self):
        """Health check endpoint for Ray Serve."""
        try:
            await self._ensure_ready()
            return {"status": "healthy", "service": "BMI MCP Gateway"}
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            raise HTTPException(status_code=503, detail="Service unhealthy")

    @app.get("/tools")
    async def list_tools(self):
        """List all available BMI calculation tools."""
        try:
            tools = await self._list_tools()
            return {"tools": tools}
        except Exception as e:
            logger.error(f"Failed to list tools: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/call")
    async def call_tool(self, request: Request):
        """Generic tool calling endpoint."""
        try:
            body = await request.json()
            tool_name = body.get("tool_name")
            tool_args = body.get("tool_args", {})

            if not tool_name:
                raise HTTPException(
                    status_code=400, 
                    detail="Missing 'tool_name' in request body"
                )

            result = await self._call_tool(tool_name, tool_args)
            return {"result": result}

        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Tool call failed: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    # @app.post("/bmi/calculate")
    # async def calculate_bmi_direct(self, request: Request):
    #     """
    #     Direct BMI calculation endpoint with validation and categorization.
        
    #     Expected request body:
    #     {
    #         "weight_kg": 70.0,
    #         "height_m": 1.75
    #     }
    #     """
    #     try:
    #         body = await request.json()
    #         weight_kg = body.get("weight_kg")
    #         height_m = body.get("height_m")

    #         # Validation
    #         if weight_kg is None or height_m is None:
    #             raise HTTPException(
    #                 status_code=400,
    #                 detail="Both 'weight_kg' and 'height_m' are required"
    #             )

    #         # Convert to float and validate ranges
    #         try:
    #             weight_kg = float(weight_kg)
    #             height_m = float(height_m)
    #         except (ValueError, TypeError):
    #             raise HTTPException(
    #                 status_code=400,
    #                 detail="Weight and height must be valid numbers"
    #             )

    #         # Sanity checks
    #         if not (1.0 <= weight_kg <= 1000.0):
    #             raise HTTPException(
    #                 status_code=400,
    #                 detail="Weight must be between 1 and 1000 kg"
    #             )

    #         if not (0.3 <= height_m <= 3.0):
    #             raise HTTPException(
    #                 status_code=400,
    #                 detail="Height must be between 0.3 and 3.0 meters"
    #             )

    #         # Call the BMI calculation tool
    #         result = await self._call_tool(
    #             "calculate_bmi", 
    #             {"weight_kg": weight_kg, "height_m": height_m}
    #         )

    #         # Extract BMI value from result
    #         if hasattr(result, 'content') and result.content:
    #             bmi_value = float(result.content[0].text)
    #         else:
    #             # Fallback calculation if tool result format is unexpected
    #             bmi_value = weight_kg / (height_m ** 2)

    #         # Add category information
    #         category = self._get_bmi_category(bmi_value)

    #         return {
    #             "bmi": round(bmi_value, 2),
    #             "category": category,
    #             "weight_kg": weight_kg,
    #             "height_m": height_m,
    #             "tool_result": result
    #         }

    #     except HTTPException:
    #         raise
    #     except Exception as e:
    #         logger.error(f"BMI calculation failed: {e}")
    #         raise HTTPException(status_code=500, detail=str(e))

    async def __del__(self):
        """Cleanup resources on deployment shutdown."""
        try:
            if self._exit_stack:
                await self._exit_stack.aclose()
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")


# Ray Serve app binding
bmi_gateway = BMIDeployment.bind()

if __name__ == "__main__":
    # For local testing/development
    serve.run(bmi_gateway, host="0.0.0.0", port=8000)